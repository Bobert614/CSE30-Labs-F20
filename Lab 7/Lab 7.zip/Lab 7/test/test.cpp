#include <igloo/igloo.h>
#include <SortedArray.h>
#include <Array.h>
#include <TimeSupport.h>
#include <RandomSupport.h>

using namespace igloo;

int main() {
	// Run all the tests defined above
	return TestRunner::RunAllTests();
}
